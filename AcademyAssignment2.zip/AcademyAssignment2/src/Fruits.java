public class Fruits {
    String frtName;
    Integer frtPrice;

}
